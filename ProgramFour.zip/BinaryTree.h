/*********************************************************************************
 *     Title:   BinaryTree.h                                                     *
 *     Author:  Jamison Boyd
 *     Date:    March 29, 2018                                                   *
 *     Purpose: This is the specification file for the BinaryTree class, which   *
 *              is an implementation of a Binary Search Tree.  Each Tree Node    *
 *              stores a customer name (string) and the number of Krabby Patties *
 *              the customer ate.                                                *
 *********************************************************************************/
#ifndef BINARYTREE_H
#define BINARYTREE_H
#include <iostream>
#include <string>
using namespace std;


class BinaryTree
{
    private:
		struct TreeNode
		{
			string   custName;
			int      atePatties;
			TreeNode *left;
			TreeNode *right;
		};
		
		TreeNode   *root;
		void       insert(TreeNode *&, TreeNode *&);
		void       insertInt(TreeNode *&, TreeNode *&);
		void       displayInOrder(TreeNode *) const;
		void       destroySubTree(TreeNode *);
		int        getLeast(TreeNode*, string&);
		int        getHighest(TreeNode*, string&);
		int        getTotal(TreeNode*);
		BinaryTree sort(TreeNode*) const;
    
    public :
		     BinaryTree();
		     ~BinaryTree();
		void insertNode(string, int);
		void insertIntNode(string, int);
		void deleteNode(TreeNode *&, string);
		void remove(string);
		void makeDeletion(TreeNode *&);
		void displayInOrder();
		int  searchNode(string);
		void getLeastNumPatties(string &, int);
		void getHighestNumPatties(string &, int);
		int  getTotalNumPatties();
		bool isEmpty();
		void sort() const;
};


#endif
