/*********************************************************************************
 *     Title:   KrustyKrab.cpp                                                   *
 *     Author:  April Crockett, modified by Jamison Boyd                         *
 *     Date:    March 29, 2018                                                   *
 *     Purpose: This is a program for Mr. Krabs at the Krusty Krab in beautiful  *
 *              Bikini Bottom!  The program allows you to choose from a menu     *
 *              of options:  enter customer data, remove customer data, print    *
 *              statistics, and search for a customer's data.  This data in this *
 *              program is stored in a Binary Search Tree.                       *
 *********************************************************************************/

#include "BinaryTree.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	string name, temp, temp1;
    int total = 0, tempPatties = 0, tempPatties1 = 0, numKrabbyPatties, choice, min, max, check;
    BinaryTree customers, intTemp;

	cout << "\n\n_  _   ____   _  _    ___   _____  _  _     _  _   ____     _    ___  \n";
	cout << ") |) / /  _ \\ ) () (  (  _( )__ __() () (   ) |) / /  _ \\   )_\\  \\  _)\n"; 
	cout << "| ( (  )  ' / | \\/ |  _) \\    | |  '.  /    | ( (  )  ' /  /( )\\ |  ( \n"; 
	cout << ")_|)_\\ |_()_\\ )____( )____)   )_(   /_(     )_|)_\\ |_()_\\ )_/ \\_(/__o)\n\n";

	do
	{
		cout << "Welcome to the Krusty Krab!\n";
		cout << "Choose one of the following options:\n";
		cout << "1.  Enter customer data.\n";
		cout << "2.  Remove a customer's data.\n";
		cout << "3.  Get statistics on Krabby Patties.\n";
		cout << "4.  Search for a customer's data.\n";
		cout << "5.  End Program.\n";
		cout << "ENTER 1-5:  ";
		cin >> choice;
		
		while(choice < 1 || choice > 5)
		{
			cout << "Invalid choice.  Please enter 1-5:  ";
			cin >> choice;
		}
		switch(choice)
		{
			case 1:
				do
				{
					cout << "Enter a customer's name or -1 to quit entering data.\n";
					cout << "NAME:  ";
					cin.ignore();
					getline(cin, name);
					if(name != "-1")
					{
						cout << "NUMBER KRABBY PATTIES EATEN:  ";
						cin >> numKrabbyPatties;
                        customers.insertNode(name, numKrabbyPatties);
                        intTemp.insertIntNode(name, numKrabbyPatties);
					}
				} while ( name != "-1" );
				cout << endl;
				break;
			
			case 2: 
                if ( customers.isEmpty() == false )
                {
                    cout << endl << endl << "You may remove the following customers: " << endl;
                    customers.displayInOrder();
                    cout << endl << endl << "Enter the name of the customer you wish to remove: " << endl;
                    cout << "NAME:  ";
                    cin.ignore();
                    getline(cin, name);
                    cout << endl;
                    customers.remove(name);
                    cout << endl;
                }
                else
                    cout << "There are no customers to remove." << endl << endl;
				break;
		
			case 3: // Not having these blank cout statements crashes the program. Don't ask me why, it's weird. I had regular cout's and it worked, and when I took them out it crashed.
				if ( customers.isEmpty() == false )
				{	
					cin.ignore();
					intTemp.sort();
					cout << "" << endl << endl;
					intTemp.getLeastNumPatties(temp, tempPatties);
					intTemp.getHighestNumPatties(temp1, tempPatties1);
					cout << "TOTAL NUMBER OF KRABBY PATTIES EATEN: " << customers.getTotalNumPatties() << endl << endl;
					break;
				}
				else
					cout << "There are no customers to remove." << endl << endl;
				break;
				
			case 4: 
			 if ( customers.isEmpty() == false )
             {
				cout << "\n\nWhich customer are you looking for?\n";
                customers.displayInOrder();
				cout << "Enter the name of the customer.\n";
				cout << "NAME:  ";
				cin.ignore();
				getline(cin, name);
                check = customers.searchNode(name);
                if(check == -1)
                {
                    cout << name << " is not in the Krusty Krab" << endl << endl;
                }
                else
                {
                    cout << "\n" << name << " ate " << customers.searchNode(name) << " Krabby Patties." << endl;
                }
                break;
			}
            else
				cout << "There are no customers to remove." << endl << endl;
			break;
			
			case 5: 
				cout << "\n\nGoodbye!\n\n";
		}
	}while(choice != 5);
	
	return 0;
}
