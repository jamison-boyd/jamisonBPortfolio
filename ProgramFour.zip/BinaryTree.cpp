/*********************************************************************************
 *     Title:   BinaryTree.cpp                                                   *
 *     Author:  Jamison Boyd                                                    *
 *     Date:    March 29, 2018                                                   *
 *     Purpose: This is the implementation file for the BinaryTree class, which  *
 *              is an implementation of a Binary Search Tree.  Each Tree Node    *
 *              stores a customer name (string) and the number of Krabby Patties *
 *              the customer ate.                                                *
 *********************************************************************************/
#include <iostream>
#include <string>
#include "BinaryTree.h"
 
using namespace std;

BinaryTree::BinaryTree()
{
	root = NULL;
}

BinaryTree::~BinaryTree()
{
	destroySubTree(root);
}
void BinaryTree::insert(TreeNode *&nodePtr, TreeNode *&newNode)
{
    if (nodePtr == NULL)
        nodePtr = newNode;
    else if (newNode->custName < nodePtr->custName)
        insert(nodePtr->left, newNode);
    else
        insert(nodePtr->right, newNode);
}

void BinaryTree::insertInt(TreeNode *&nodePtr, TreeNode *&newNode)
{
    if (nodePtr == NULL)
        nodePtr = newNode;
    else if (newNode->atePatties < nodePtr->atePatties)
        insertInt(nodePtr->left, newNode);
    else
        insertInt(nodePtr->right, newNode);
}

void BinaryTree::insertNode(string newName, int patties)
{
    TreeNode* newNode = new TreeNode;
    newNode->custName = newName;
    newNode->atePatties = patties;
    newNode->left = newNode->right = NULL;
    insert(root, newNode);
}

void BinaryTree::insertIntNode(string newName, int patties)
{
    TreeNode* newNode = new TreeNode;
    newNode->custName = newName;
    newNode->atePatties = patties;
    newNode->left = newNode->right = NULL;
    insertInt(root, newNode);
}


bool BinaryTree::isEmpty()
{
    if(root == NULL)
        return true;
    else
        return false;
}

void BinaryTree::destroySubTree(TreeNode *nodePtr)
{
    if (nodePtr)
    {
        if (nodePtr->left)
            destroySubTree(nodePtr->left);
        if (nodePtr->right)
            destroySubTree(nodePtr->right);
        delete nodePtr;
    }
}

void BinaryTree::displayInOrder()
{
    displayInOrder(root);
}

void BinaryTree::displayInOrder(TreeNode *nodePtr) const
{
    if (nodePtr)
    {
        displayInOrder(nodePtr->left);
        cout << nodePtr->custName << endl;
        displayInOrder(nodePtr->right);
    }
}

int BinaryTree::searchNode(string value)
{
    TreeNode *nodePtr = root;
    while(nodePtr)
    {
        if (nodePtr->custName == value)
            return nodePtr->atePatties;
        else if (value < nodePtr->custName)
            nodePtr = nodePtr->left;
        else
            nodePtr = nodePtr->right;
    }
    return -1;
}

void BinaryTree::remove(string value)
{
    cout << "You are trying to remove " << value << ". " << endl;
    deleteNode(root, value);
}

void BinaryTree::deleteNode(TreeNode* &nodePtr, string value)
{
    int check = searchNode(value);
    if(check == -1)
        cout << value << " is not a current customer of the Krusty Krab." << endl;
    else if(value < nodePtr->custName)
        deleteNode(nodePtr->left, value);
    else if (value > nodePtr->custName)
        deleteNode(nodePtr->right, value);
    else
        makeDeletion(nodePtr);
}

void BinaryTree::makeDeletion(TreeNode* &nodePtr)
{
    TreeNode* tempNodePtr;
    if (nodePtr == NULL)
        cout << "There are no customers to remove." << endl;
    else if(nodePtr->right == NULL)
    {
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->left;
        cout << "You deleted " << tempNodePtr->custName << endl;
        delete tempNodePtr;
    }
    else if (nodePtr->left == NULL)
    {
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->right;
        cout << "You deleted " << tempNodePtr->custName << endl;
        delete tempNodePtr;
    }
    else
    {
        tempNodePtr = nodePtr->right;
        while (tempNodePtr->left)
            tempNodePtr = tempNodePtr->left;
        tempNodePtr->left = nodePtr->left;
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->right;
        cout << "You deleted " << tempNodePtr->custName << endl;
        delete tempNodePtr;
    }
}

void BinaryTree::getLeastNumPatties(string &name, int leastPatties)
{
    leastPatties = root->atePatties;
    cout << name << " ate the least amount of Krabby Patties, being at: " <<  getLeast(root, name) << endl;
}

int BinaryTree::getLeast(TreeNode *nodePtr, string &name)
{
    if (nodePtr->left == NULL)
    {
        name = nodePtr->custName;
        return nodePtr->atePatties;
    }
    else
        return (getLeast(nodePtr->left, name));
}

void BinaryTree::getHighestNumPatties(string &name, int highestPatties)
{
    highestPatties = root->atePatties;
    cout << name << " ate the most Krabby Patties, being at: " << getHighest(root, name) << endl;
}

int BinaryTree::getHighest(TreeNode *nodePtr, string &name)
{
    int temp;
    if (nodePtr->right == NULL)
    {
        cout << "" << endl;
        name = nodePtr->custName;
        temp = nodePtr->atePatties;
        if(temp > nodePtr->left->atePatties)
            return temp;
        else
        {
            name = nodePtr->left->custName;
            return nodePtr->left->atePatties;
        }
    }
    else
        return getHighest(nodePtr->right, name);
}

int BinaryTree::getTotalNumPatties()
{
    int total = 0;
    return getTotal(root);
}

int BinaryTree::getTotal(TreeNode* nodePtr)
{
    int sum;
    int leftSum;
    int rightSum;
    if(nodePtr == NULL)
    {
        sum = 0;
        return sum;
    }
    else
    {
        leftSum = getTotal(nodePtr->left);
        rightSum = getTotal(nodePtr->right);
        sum = nodePtr->atePatties + leftSum + rightSum;
        return sum;
    }
}

void BinaryTree::sort() const
{
    sort(root);
}

BinaryTree BinaryTree::sort(TreeNode *nodePtr) const
{
    BinaryTree *tree = new BinaryTree;
    if(nodePtr)
    {
        sort(nodePtr->left);
        tree->insertIntNode(nodePtr->custName, nodePtr->atePatties);
        sort(nodePtr->right);
    }
    return *tree;
}
