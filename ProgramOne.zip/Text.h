/*
	Title:  Text.h
	Author:  Jamison Boyd
	Date:  9/7/2015
	About:  A class version of the C++ string class
*/

#ifndef TEXT_H
#define TEXT_H

#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

class Text
{
	private: 
		const char* textArray; // Array of characters, so a word or sentence
		int textLength; // size of the array
		
	public:
		/*
			Function Name: Text();
			Parameters: A Const Character Array, mainly a textArray.
			Returns: None.
			Purpose: This is the Text constructor, which creates an object of the type Text*
		*/
		Text(const char*);
		/*
			Function Name: ~Text();
			Parameters: None.
			Returns: None.
			Purpose: To delete the textArray, so it's not left in memory
		*/
		~Text();
		/*
			Function Name: displayText();
			Parameters: None.
			Returns: None.
			Purpose: To display the text array that is calling this function.
		*/
		void displayText() const;
		/*
			Function Name: getText();
			Parameters: None.
			Returns: textArray
			Purpose: To return the textArray of the object calling this function.
		*/
		const char* getText() const;
		/*
			Function Name: getLength();
			Parameters: None
			Returns: textLength
			Purpose: To return the length of the array of the object calling this function
		*/
		int getLength() const;
		/*
			Function Name: editText();
			Parameters: const char*;
			Returns: None.
			Purpose: To edit the text of the array given to the function as a parameter
		*/
		void editText(const char*);
};

#endif