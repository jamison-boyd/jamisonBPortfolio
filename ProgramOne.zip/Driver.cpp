/*
	Title:  Driver.cpp
	Author:  Jamison Boyd
	Date:  9/7/2017
	Purpose:  To demonstrate the Movies, Movie, and Text structure code working
	by allowing the user to add, save, delete, and edit movies to/from a library.
*/

#include "Movies.h" // need all the header files
#include "Movie.h"
#include "Text.h"
#include <iostream>
using namespace std;

int main()
{
	int menuChoice;
	int maxMovies;
	char filename[25];
	
	cout << endl << endl << "What is the maximum number of movies you can have in your library?: ";
	cin >> maxMovies;
	while(maxMovies <= 0)
	{
		cout << endl << endl << "You need to have at least one movie in your library." << endl;
		cout << "What is maximum number of movies you can have in your library? (More than 0): ";
		cin >> maxMovies;
	}
	Movies* movieLibrary = new Movies(maxMovies); // creates a new movie array using the construcotr
	
	do{
		cout << endl << endl << "What would you like to do? " << endl;
		cout << "1.   Read movies from file." << endl;
		cout << "2.   Save movies to a file." << endl;
		cout << "3.   Add a movie." << endl;
		cout << "4.   Delete a movie." << endl;
		cout << "5.   Edit a movie." << endl;
		cout << "6.   Print all movies." << endl;
		cout << "7.   Delete ALL movies and end the program." << endl;
		cin >> menuChoice;
		while(menuChoice < 1 || menuChoice > 7) // makes sure the user enters a vlaid choice
		{
			cout << "Please enter a valid choice (1-7): ";
			cin >> menuChoice;
		}
		
		switch(menuChoice) // switches between the users choices of things to do
		{
			case(1):
				cout << endl << endl << "What is the name of the file? (example.txt): ";
				cin >> filename;
				movieLibrary->readMoviesFromFile(filename);
				break;
			case(2):
				cout << endl << endl << "What do you want to name the file? (example.txt): ";
				cin >> filename;
				movieLibrary->saveToFile(filename);
				break;
			case(3): 
				movieLibrary->addMovieToArray();
				break;
			case(4):
				movieLibrary->removeMovieFromArray();
				break;
			case(5):
				movieLibrary->editMovieInArray();
				break;
			case(6):
				movieLibrary->displayMovies();
				break;
			case(7):
				delete movieLibrary;
				break;
		}
	} while (menuChoice != 7); // if movieChoice = 7, the program deletes all the movies, attributes, and end the program
	
	cout << endl << endl << "End of Program.";
	
	return 0;
}