/*
	Title:  Movies.h
	Author:  Jamison Boyd
	Date:  9/7/2017
	Purpose:  Be able to create, manage, print & delete a single movie.
*/

#ifndef MOVIES_H
#define MOVIES_H

#include "Movie.h"
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

class Movies
{
	private:
		Movie** moviesArray; // Array of Movie Objects
		int maxMovies; // Maximum amount of movies in the array
		int numMovies; // Current amount of movies in the array
		
	public:
		/*
			Function Name: Movies();
			Parameters: int maxMovies;
			Returns: None.
			Purpose: Movies Constructor of the Array of Movie objects
		*/
		Movies(int);
		/*
			Function Name: addMovieToArray();
			Parameters: None.
			Returns: None.
			Purpose: To add a new, user created Movie to the array.
		*/
		void addMovieToArray();
		/*
			Function Name: editMovieInArray();
			Parameters: None.
			Returns: None.
			Purpose: To select a Movie in the array to edit
		*/
		void editMovieInArray();
		/*
			Function Name: ~Movies();
			Parameters: None.
			Returns: None.
			Purpose: To delete the Array of Movies
		*/
		~Movies();
		/*
			Function Name: displayMovies();
			Parameters: None.
			Returns: None.
			Purpose: To display the array of Movies with all the attributes to the command prompt
		*/
		void displayMovies();
		/*
			Function Name: displayMovieTitles();
			Parameters: None.
			Returns: None.
			Purpose: To display the Movie Titles of all the movies in the array.
		*/
		void displayMovieTitles();
		/*
			Function Name: readMoviesFromFile();
			Parameters: char* filename;
			Returns: None.
			Purpose: To read in the Movies and their attributes from a given file
		*/
		void readMoviesFromFile(char* filename);
		/*
			Function Name: removeMovieFromArray();
			Parameters: None.
			Returns: None.
			Purpose: To let the user select a Movie from the Array to delete.
		*/
		void removeMovieFromArray();
		/*
			Function Name: saveToFile();
			Parameters: char* filename;
			Returns: None.
			Purpose: To save all the contents of the Movie Array to a given file.
		*/
		void saveToFile(char* filename);
		/*
		Function Name: resizeMovieArray();
		Parameters: None.
		Returns: None.
		Purpose: To resize the array of the movie array to two times the max size.
		*/
		void resizeMovieArray();
		/*
		Function Name: getNumMovies();
		Parameters: None.
		Returns: numMovies;
		Purpose: To return the current number of movies in the array.
		*/
		int getNumMovies();
		/*
		Function Name: getMaxMovies();
		Parameters: None.
		Returns: maxMovies;
		Purpose: To return the max movies of the array.
		*/
		int getMaxMovies();
};

#endif