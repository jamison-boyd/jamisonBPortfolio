/*
	Title:  Text.cpp
	Author:  Jamison Boyd	
	Date:  9/7/2017
	About:  A class version of the C++ string class
*/

#include "Text.h"
#include <iostream>
#include <cstring>
using namespace std;

 Text::Text(const char* text) // Text Constructor, dynamically allocated a temp array, copied the given one to the temp, sets the given one to the temp. Sets the size
 {	
	textLength = strlen(text);
	
	char* tempTextArray = new char[textLength+1];
	
	strcpy(tempTextArray, text);
	
	this->textArray = tempTextArray;
}

Text::~Text() // Text Destructor
{
	delete textArray;	
}

void Text::displayText() const // Displays the textArray
{
	cout << textArray;
}

const char* Text::getText() const // returns the textArray
{
	return textArray;
}

int Text::getLength() const // returns the length of the textArray
{
	return textLength;
}

void Text::editText(const char* newText) // Used to edit the textArray
{
	delete [] textArray;
	textLength = strlen(newText);
	char* tempNewArray = new char[textLength+1];
	strcpy(tempNewArray, newText);
	this->textArray = tempNewArray;
}