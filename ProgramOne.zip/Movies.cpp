/*
	Title:  Movies.cpp
	Author:  Jamison Boyd
	Date:  9/7/2017
	Purpose:  Be able to create, manage, print, save & delete a movie library
*/
#include "Movies.h"
#include "Movie.h"
#include "Text.h"

Movies::Movies(int max) // Constructor, sets the values of the attributes
{
	maxMovies = max;
	numMovies = 0;
	moviesArray = new Movie*[max];
}

void Movies::resizeMovieArray() // Have to have this before addMovieToArray because program won't work if not
{
	int max = maxMovies * 2; //double size by 2
	
	//make an array that is twice as big as the current one
	Movie** newMoviesArray = new Movie*[max];
	for(int i = 0; i < numMovies; i++)
	{
		newMoviesArray[i] = moviesArray[i];
	}
	
	//delete the original array from memory
	delete [] moviesArray;
	
	moviesArray = newMoviesArray;
	maxMovies = max;
}

void Movies::addMovieToArray() // Adds a movie that the user creates by giving the command prompt input
{
	char temp[100];
	int length, year, numOscars;
	double numStars;
	Text* title;
	Text* genre;
	Text* rating;
	
	cin.ignore();
	cout << endl << endl << "Movie Title: ";
	cin.getline(temp, 100);
	title = new Text(temp);
	cout << endl << "Movie Length (in Minutes): ";
	cin >> length;
	cout << endl << "Movie Year: ";
	cin >> year;
	cin.ignore();
	cout << endl << "Movie Genre: ";
	cin.getline(temp, 100);
	genre = new Text(temp);
	cout << endl << "Movie Rating: ";
	cin.getline(temp, 100);
	rating = new Text(temp);
	cout << endl << "Number of Oscars Won: ";
	cin >> numOscars;
	cout << endl << "Star Rating ( out of 10 ): ";
	cin >> numStars;
	
	Movie* oneMovie = new Movie(title, length, year, genre, rating, numOscars, numStars); // calls the constructor of the movie with the given attributes
	
	if(numMovies == maxMovies) // resize the array if at max
	{
		resizeMovieArray();
	}
	moviesArray[numMovies] = oneMovie;
	
	(numMovies)++;
}

void Movies::removeMovieFromArray() // User selects a movie to remove from the array
{
	int movieChoice;
	cout << numMovies << endl << endl;
	if((numMovies) <= 1)
	{
		cout << endl << "There must be at least one movie in your library. You can\'t";
		cout << " remove any movies because there will be no more movies in the library." << endl;
	} else
	{
		cout << endl << endl << "Choose from the following movies to remove:\n";
		displayMovieTitles();
		cout << endl << "Choose a movie to remove between 1 & " << numMovies << ":  ";
		cin >> movieChoice;
		while(movieChoice < 1 || movieChoice > numMovies)
		{
			cout << endl << "Oops!  You must enter a number between 1 & " << numMovies << ":  ";
			cin >> movieChoice;
		}
		int movieIndexToBeRemoved = movieChoice-1; // Off by One error fix
		
		Text* movieTitle = moviesArray[movieIndexToBeRemoved]->movieTitle; 

		moviesArray[movieIndexToBeRemoved]->Movie::~Movie(); // deletes the movie the user chose
		
		int numElementsToMoveBack = (numMovies) - 1;
		
		for(int i = movieIndexToBeRemoved; i < numElementsToMoveBack; i++) // makes sure there isnt a space in the array with nothing, so it movies all the movies over
		{
			moviesArray[i] = moviesArray[i+1]; 
		}
	
		moviesArray[numElementsToMoveBack] = NULL; // nulls out the space of the deleted movie
		
		(numMovies)--;
		
		cout << endl << endl << "The movie \"";
		movieTitle->Text::displayText();
		cout << "\" has been successfully deleted.\n";	
	}
}

void Movies::editMovieInArray() // lets the user select a movie to edit
{
	int movieChoice;
	
	cout << endl << endl << "Choose from the following movies to edit: " << endl;
	displayMovieTitles();
	cout << endl <<"Choose a movie to remove between 1 & " << numMovies << ":  ";
	cin >> movieChoice;
	while(movieChoice < 1 || movieChoice > numMovies)
	{
		cout << endl << "Oops!  You must enter a number between 1 & " << numMovies << ":  ";
		cin >> movieChoice;
	}
	Movie* oneMovie = moviesArray[movieChoice-1];
	oneMovie->editMovie();
}

Movies::~Movies() // Movies Destructor
{
	//delete each movie
	for(int i = 0; i < numMovies; i++)
	{
		//deletes each movie in the array
		delete moviesArray[i];
	}
	
	//delete movies array
	delete [] moviesArray;
	
}
	
void Movies::displayMovies() // displays all the movies and their attributes
{
	if(numMovies > 0)
	{
		for(int i = 0; i < (numMovies); i++)
		{
			cout << endl << right << setw(50) << "----------MOVIE " << (i+1) << "----------";
			moviesArray[i]->printMovieDetails(); //function is in Movie.cpp
		}
	}
	else	
		cout << endl << "There are no movies in your library yet.";
}

void Movies::displayMovieTitles() // displays only the movie titles
{
	Text* movieTitle;
	
	for(int i = 0; i < (numMovies); i++)
	{
		cout << endl << "MOVIE " << (i+1) <<": ";
		movieTitle = moviesArray[i]->getMovieTitle();
		movieTitle->Text::displayText();
	}
}

void Movies::readMoviesFromFile(char *filename) // gets the movies from a file instead of all user input
{
	int numMoviesReadFromFile = 0;
	ifstream inFile;
	char temp[100];
	Text* title;
	Text* genre;
	Text* rating;
	Movie* oneMovie;
	int movieLength; //length of movie in minutes
	int movieYear; //year released
	int movieOscars; //number of oscars won
	float movieNumStars; //from IMDB out of 10 stars
	
	
	inFile.open(filename);
	if(inFile.good())
	{
		inFile.getline(temp, 100);
		while(!inFile.eof())
		{
			title = new Text(temp);// a dynamically allocated Text* object
			inFile >> movieLength;
			inFile >> movieYear;
			inFile.ignore(); //get rid of \n in the inFile buffer
		
			inFile.getline(temp, 100); //read in genre
			genre = new Text(temp); //create a text for genre
			inFile.getline(temp, 100); //read in rating
			rating = new Text(temp); //create a text for rating
			inFile >> movieOscars;
			inFile >> movieNumStars;
			inFile.ignore(); //get rid of \n in the inFile buffer
	
		 
			oneMovie = new Movie(title, movieLength, movieYear, genre, rating, movieOscars, movieNumStars); // creates a new Movie objext

			if(numMovies == maxMovies)
			{
				resizeMovieArray();	//double size by 2
			}
			moviesArray[numMovies] = oneMovie;

			(numMovies)++;
			
			cout << endl;
			title->displayText();
			cout << " was added to the movie library!" << endl; // lets user know the movie was added
			
			
			inFile.getline(temp, 100); //read in the next movie title if there is one
			
			numMoviesReadFromFile++;
		}
		
		cout << endl << endl << numMoviesReadFromFile << " movies were read from the file and added to your movie library." << endl << endl; // shows how many movies were added
	}
	else
	{
		cout << endl << endl << "ERROR: Unable to open file." << endl; // if file couldnt open, this displays instead
	}
}

void Movies::saveToFile(char *filename) // saves the movies and the attributes to a given file
{
	ofstream outFile;
	
	outFile.open(filename);
	
	for(int i = 0; i < (numMovies); i++)
	{
		moviesArray[i]->printMovieDetailsToFile(outFile); 
	}

	outFile.close();
	
	cout << endl << endl << "All movies in your library have been printed to " << filename << endl;
}

