/*
	Title:  Movie.h
	Author:  Jamison Boyd
	Date:  9/7/2017
	Purpose:  Be able to create, manage, print & delete a single movie.
*/

#ifndef MOVIE_H
#define MOVIE_H

#include "Text.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;

class Movie
{
	private:
		Text* movieGenre; // Text* object for the movie's genre
		Text* movieRating; // Text* object for the movie's rating (G, PG, PG-13, R)
		int movieLength; // Length of the movie in minutes
		int movieYear; // Year the movie came out
		int movieOscars; // Number of Oscars the movie has one
		float movieNumStars; // IMDb Stars rating out of 10
	public: 
		Text* movieTitle; // movieTitle Text* object. Needs to be public so it can be accessed.
		/*
			Function Name: Movie()
			Parameters: Text* title, int length
			Returns: None
			Purpose: Movie Constructor that creates a shorter version
		*/
		Movie(Text*, int);
		/*
			Function Name: Movie();
			Parameters: Text* title, int length, int year, Text* genre, Text* rating, int oscars, float stars
			Returns: None.
			Purpose: Overloaded Movie Constructor, main one used to create the movies to store, edit, etc.
		*/
		Movie(Text*, int, int, Text*, Text*, int, float);
		/*
			Function Name: editMovie();
			Parameters: None.
			Returns: None.
			Purpose: To edit a certain movie's attributes
		*/
		void editMovie();
		/*
			Function Name: ~Movie();
			Parameters: None.
			Returns: None.
			Purpose: To delete the dynamically allocated attributes of the Movie object
		*/
		~Movie();
		/*
			Function Name: printMovieDetails();
			Parameters: None.
			Returns: None.
			Purpose: To print all the details of the movie to the command prompt.
		*/
		void printMovieDetails();
		/*
			Function Name: printMovieDetailsToFile();
			Parameters: ofstream &outfile
			Returns: None.
			Purpose: To print all the attributes of the movie to the given outfile
		*/
		void printMovieDetailsToFile(ofstream &outFile);


		// Getter or Accessor Functions
		/*
			Function Name: getMovieTitle();
			Parameters: None
			Returns: The movie title
			Purpose: To return the movie title of the object calling this function
		*/
		Text* getMovieTitle(); 
		/*
			Function Name: getMovieLength();
			Parameters: None
			Returns: The movie length
			Purpose: To return the movie length of the object calling this function
		*/
		int getMovieLength();
		/*
			Function Name: getMovieYear();
			Parameters: None
			Returns: The movie release year
			Purpose: To return the movie year of the object calling this function
		*/
		int getMovieYear();
		/*
			Function Name: getMovieGenre();
			Parameters: None
			Returns: The movie genre
			Purpose: To return the movie genre of the object calling this function
		*/
		Text* getMovieGenre();
		/*
			Function Name: getMovieRating();
			Parameters: None
			Returns: The movie rating
			Purpose: To return the movie rating of the object calling this function
		*/
		Text* getMovieRating();
		/*
			Function Name: getMovieOscars();
			Parameters: None
			Returns: The movie's number of oscars
			Purpose: To return the movie's number of oscars of the object calling this function
		*/
		int getMovieOscars();
		/*
			Function Name: getMovieNumStars();
			Parameters: None
			Returns: The movie's number of stars on IMDb
			Purpose: To return the movie's number of stars on IMDb of the object calling this function
		*/
		float getMovieNumStars();


		//Setter or Mutator Functions
		/*
			Function Name: setMovieTitle();
			Parameters: Text* title
			Returns: None.
			Purpose: To set the title of the movie/object calling this function
		*/
		void setMovieTitle(Text* title);
		/*
		Function Name: setMovieLength();
		Parameters: int length
		Returns: None.
		Purpose: To set the length of the movie/object calling this function
		*/
		void setMovieLength(int length);
		/*
		Function Name: setMovieYear();
		Parameters: int year
		Returns: None.
		Purpose: To set the year of the movie/object calling this function
		*/
		void setMovieYear(int year);
		/*
		Function Name: setMovieGenre();
		Parameters: Text* genre
		Returns: None.
		Purpose: To set the genre of the movie/object calling this function
		*/
		void setMovieGenre(Text* genre);
		/*
		Function Name: setMovieRating();
		Parameters: Text* rating
		Returns: None.
		Purpose: To set the rating of the movie/object calling this function
		*/
		void setMovieRating(Text* rating);
		/*
		Function Name: setMovieOscars();
		Parameters: int oscars
		Returns: None.
		Purpose: To set the number of Oscars of the movie/object calling this function
		*/
		void setMovieOscars(int oscars);
		/*
		Function Name: setMovieNumStars();
		Parameters: float stars
		Returns: None.
		Purpose: To set the number of Stars of the movie/object calling this function
		*/
		void setMovieNumStars(float stars);
};

#endif