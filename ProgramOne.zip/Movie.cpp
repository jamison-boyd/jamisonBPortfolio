/*
	Title:  Movie.cpp
	Author: Jamison Boyd
	Date:  9/7/2017
	Purpose:  Be able to create, manage, print & delete a single movie.
*/

#include "Movie.h"
#include "Text.h"

Movie::Movie(Text* title, int length) // Movie Constructor
{
	//setMovieTitle(movieTitle);
	//setMovieLength(movieLength); 
	movieLength = length;
	movieTitle = title;

}

Movie::Movie(Text* title, int length, int year, Text* genre, Text* rating, int nom, float stars) // Overloaded Movie Constructor using all the attributes
{
/* 	setMovieNumStars(movieNumStars);
	setMovieYear(movieYear);
	setMovieGenre(movieGenre);
	setMovieRating(movieRating);
	setMovieOscars(movieOscars);
	setMovieLength(movieLength);
	setMovieTitle(movieTitle);  */
	movieTitle = title;
	movieLength = length;
	movieYear = year;
	movieGenre = genre;
	movieRating = rating;
	movieOscars = nom;
	movieNumStars = stars;
}


Movie::~Movie() // Movie Deconstructor
{
	movieTitle->Text::~Text();
	movieGenre->Text::~Text();
	movieRating->Text::~Text();
}

void Movie::printMovieDetails() // prints all the movie details to the command prompt
{
	cout << endl;
	cout << right << setw(30) << "Movie Title:  " << left;
	// << "Before Movie Title" << endl;
	movieTitle->displayText(); // movieTitle points to the function in the same scope
	cout << endl;
	cout << right << setw(30) << "Length (minutes):  " << left << movieLength << endl;
	cout << right << setw(30) << "Year Released:  " << left << movieYear << endl;
	cout << right << setw(30) << "Genre:  " << left;
	//cout << "Before Movie Genre" << endl;
	movieGenre->displayText();
	cout << endl;
	cout << right << setw(30) << "Rating:  " << left;
	//cout << "Before Movie Rating" << endl;
	movieRating->displayText();
	cout << endl;
	cout << right << setw(30) << "Number of Oscars Won:  " << left << movieOscars << endl;
	cout << right << setw(30) << "Number of Stars:  " << left << movieNumStars << endl << endl;
}
void Movie::printMovieDetailsToFile(ofstream &outFile) // Prints all the movie details to a given file
{
	char temp[1000];
	strncpy(temp, movieTitle->Text::getText(), 1000);
	outFile << temp << endl;
	outFile << movieLength << endl;
	outFile << movieYear << endl;
	strncpy(temp, movieGenre->Text::getText(), 1000);
	outFile << temp << endl;
	strncpy(temp, movieRating->Text::getText(), 1000);
	outFile << temp << endl;
	outFile << movieOscars << endl;
	outFile << movieNumStars << endl;
}

void Movie::editMovie() // Takes the user selected choice, lets the user edit the attributes of the movie chosen
{
	int choice;
	Text* tempText;
	char temp[100];
	
	do{
		cout << endl << endl << "Which details do you wish to edit?" << endl;
		cout << "1. Title" << endl;
		cout << "2. Length" << endl;
		cout << "3. Year" << endl;
		cout << "4. Genre" << endl;
		cout << "5. Rating" << endl;
		cout << "6. Total Oscars Received" << endl;
		cout << "7. Number of Stars" << endl;
		cout << "8. Exit" << endl;
		cout << "Choose 1 - 8: ";
		cin >> choice;
		while(choice < 1 || choice > 8)
		{
			cout << endl << "Please enter a number 1 through 8: ";
			cin >> choice;
		}
		cin.ignore();
		
		switch(choice) // Switch between which choice the user gave
		{
			case(1):
				cout << endl << "Current Movie Title: ";
				movieTitle->Text::displayText();
				movieTitle->Text::~Text();
				cout << endl << "New Title: ";
				cin.getline(temp, 100);
				tempText = new Text(temp);
				movieTitle = tempText;
				break;
				
			case(2):
				cout << endl << "Current Movie Length: " << movieLength;
				cout << endl << "New Length: ";
				cin >> movieLength;
				break;
			
			case(3):			
				cout << endl << "Current Movie Year: " << movieYear;
				cout << endl << "New Year: ";
				cin >> movieYear;
				break;
				
			case(4):
				cout << endl << "Current Movie Genre: ";
				movieGenre->Text::displayText();
				movieGenre->Text::~Text();
				cout << endl << "New Genre: ";
				cin.getline(temp, 100);
				tempText = new Text(temp);
				movieGenre = tempText;
				break;
				
			case(5):
				cout << endl << "Current Movie Rating: ";
				movieRating->Text::displayText();
				movieRating->Text::~Text();
				cout << endl << "New Rating: ";
				cin.getline(temp, 100);
				tempText = new Text(temp);
				movieRating = tempText;
				break;
				
			case(6):
				cout << endl << "Current Number of Oscars Won: " << movieOscars;
				cout << endl << "New Number of Oscars: ";
				cin >> movieOscars;
				break;
				
			case(7):
				cout << endl << "Current Star Rating from IMDB: " << movieNumStars;
				cout << endl << "New Star Rating: ";
				cin >> movieNumStars;
				break;
		}
	} while(choice != 8);
}

Text* Movie::getMovieTitle() // gets the movie title
{
	return movieTitle;
}

int Movie::getMovieLength() // gets the movie length
{
	return movieLength;
}

int Movie::getMovieYear() // gets the movie release year
{
	return movieYear;
}

Text* Movie::getMovieGenre() // gets the movie genre
{
	return movieGenre;
}

Text* Movie::getMovieRating() // gets the movie rating
{
	return movieRating;
}

int Movie::getMovieOscars() // get the movie oscars
{
	return movieOscars;
}

float Movie::getMovieNumStars() // gets the movie stars
{
	return movieNumStars;
}

void Movie::setMovieTitle(Text* title) // sets the title of the movie
{
	movieTitle = title;
}

void Movie::setMovieLength(int length) // sets the length of the movie
{
	movieLength = length;
}

void Movie::setMovieYear(int year) // sets the release year of the movie
{
	movieYear = year;
}

void Movie::setMovieGenre(Text* genre) // sets the genre of the movie
{
	movieGenre = genre;
}

void Movie::setMovieRating(Text* rating) // sets the rating of the movie
{
	movieRating = rating;
}

void Movie::setMovieOscars(int oscars) // sets the oscars of the movie
{
	movieOscars = oscars;
}

void Movie::setMovieNumStars(float stars) // sets the stars of the movie
{
	movieNumStars = stars;
}