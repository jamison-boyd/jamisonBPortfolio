/*	
	Name: Jamison Boyd
	File Name: Queue.h
	Due: 18 October 2018
	Purpose: To specify and implement the Queue class
*/
#ifndef QUEUE_H
#define QUEUE_H
#include <iostream>
using namespace std;


template <typename T>
class Queue
{
	private:

	   struct QueueNode
	   {
		  T value;			
		  QueueNode *next;	
	   };

	   QueueNode *front;  
	   QueueNode *rear;   
	   int numItems;     
	public:
	   Queue();

	   ~Queue();


	   void enqueue(T);
	   void dequeue(T &);
	   bool isEmpty() const;
	   void display() const;
};

template <typename T>
Queue<T>::Queue()
{
   front = NULL;
   rear = NULL;
   numItems = 0;
}

template <typename T>
Queue<T>::~Queue()
{
    T value;  

    while(!isEmpty())
       dequeue(value);
}


template <typename T>
void Queue<T>::enqueue(T item)
{
   QueueNode *newNode = NULL;

   newNode = new QueueNode;
   newNode->value = item;
   newNode->next = NULL;

   if (isEmpty())
   {
      front = newNode;
      rear = newNode;
   }
   else
   {
      rear->next = newNode;
      rear = newNode;
   }


   numItems++;
}

template <typename T>
void Queue<T>::dequeue(T &item)
{
   QueueNode *temp = NULL;

	if (isEmpty())
    {
      cout << "The queue is empty.\n";
    }
    else
    { 

      item = front->value;

      temp = front;
      front = front->next;
      delete temp;


      numItems--;
    }
}

template <typename T>
bool Queue<T>::isEmpty() const
{
    if (numItems > 0)
       return false;
    else
       return true;
}

template <typename T>
void Queue<T>::display() const
{
	QueueNode *nodePtr;
	if ( !front )
	{
		cout << "There is nothing to display. " << endl;
	}
	else
	{
		nodePtr = front;
		while(nodePtr)
		{
			cout << nodePtr->value;
			nodePtr = nodePtr->next;
		}
	}
}
#endif