/*	
	Name: Jamison Boyd
	File Name: Stack.h
	Due: 18 October 2018
	Purpose: To specify and implement the Stack class
*/
#ifndef STACK_H
#define STACK_H
#include <iostream>
using namespace std;


template <typename T>
class Stack
{
private:
   struct StackNode
   {
      T value;          
      StackNode *next; 
   };
   
   StackNode* head;   

public:
  int top; 
  Stack()
  { head = NULL; }
  ~Stack();
  void push(T);
  void pop(T &);
  T peek();
  bool isEmpty();
};


template <typename T>
Stack<T>::~Stack()
{
   StackNode *nodePtr, *nextNode;

   nodePtr = head;

   while (nodePtr != NULL)
   {
      nextNode = nodePtr->next;
      delete nodePtr;
      nodePtr = nextNode;
   }
}


template <typename T>
void Stack<T>::push(T item)
{
   StackNode *newNode = NULL;
   newNode = new StackNode;
   newNode->value = item;

   if (isEmpty())
   {
      head = newNode;
      newNode->next = NULL;
   }
   else  
   {
      newNode->next = head;
      head = newNode;
   }
}


template <typename T>
void Stack<T>::pop(T &item)
{
   StackNode *temp = NULL; 
   if (isEmpty())
   {
      cout << "The stack is empty." << endl;
   }
   else 
   {
      item = head->value;
      temp = head->next;
      delete head;
      head = temp;
   }
}


template <typename T>
bool Stack<T>::isEmpty()
{
	bool status;
   if (!head)
      status = true;
   else
      status = false;
  
  return status;
}

template <typename T>
T Stack<T>::peek()		
{
	StackNode *myNode;
	if(!head)
		{ cout << endl << "The stack is empty. " << endl; }
	else 
	{
		myNode = head;
	}
	return myNode->value;
}
#endif