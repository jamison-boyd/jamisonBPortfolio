/*
	Name: Jamison Boyd
	File Name: Program2.cpp
	Due: 18 October 2018
	Purpose: To convert an expression give by
	the user into "postfix" notation and then calculate
	the expression.
*/

#include "Stack.h"
#include "Queue.h"
#include <iostream>
#include <stdlib.h>
#include <string>
#include <cstring>
#include <algorithm>
using namespace std;

bool isLowerPriority(char, char);

double calculateExpression(string );
void removeSpaces(string &);
template <class T>
string algorithm(T equate); 
void addSpacesBack(string &);

int main()
{
	string infix;
	char answer;
	cout << "Infix to Postfix Converter" << endl << endl;

	do{
		cout << "Enter your Infix Equation: ";
		getline(cin, infix);
		cout << endl << endl;
		removeSpaces(infix);
		addSpacesBack(infix);
		string algInfix = algorithm(infix);
		double calcResult;
		calcResult = calculateExpression(algInfix);
		
		cout << "Result of the Expression: " << calcResult << endl << endl;
		
		
		cout << "Do you want to run the program again? (Y/N)" << endl;
		cout << "Choice: ";
		cin >> answer;
		cout << endl;
		
		cin.ignore();
	} while (answer == 'Y' || answer == 'y');
	
	cout << "Goodbye!" << endl;
	return 0;
}

template <class T>
string algorithm(T equate)
{
	int length = equate.length();
	char element;
	char token;

	int pCount = 0;
	
	Stack<char> opstack;
	Queue<char> postfix;
	Queue<char> infix;

	for (int i = 0; i < length; i++)
	{
		infix.enqueue(equate[i]);
	}
	while (!infix.isEmpty())
	{
			infix.dequeue(token);
			if (token == '(')
			{
				opstack.push(token);
			}
				
			else if (token == ')')
			{	
				while (opstack.peek() != '(')
				{	
					opstack.pop(element);
					postfix.enqueue(element);
					pCount++;
				}
				opstack.pop(token);
			}			
			else if (token == '+' || token == '-' || token == '*' || token == '/')
			{	
				while (!opstack.isEmpty() && isLowerPriority(token, opstack.peek()))
				{
					opstack.pop(element);
					postfix.enqueue(element);
					pCount++;
				}	
				opstack.push(token);
			}	
			else
			{
				postfix.enqueue(token);
				pCount++;
			}
	}	
	while (!opstack.isEmpty())
	{	
		opstack.pop(element);
		postfix.enqueue(element);
		pCount++;
	}
	
	cout <<endl << endl << "Postfix Expression: ";
	postfix.display();
	cout << endl;
	
	string postString;
	char c;
	for (int i = 0; i < pCount; i++)
	{
		postfix.dequeue(c);
		postString = postString + c;
	}
	return postString;
}


double calculateExpression(string expr)
{
	Stack<double> calcStack;
    double result; 
    for (int i = 0; i < expr.length(); i++)
    {
        if (isdigit(expr[i]))          
        {
            double num = expr[i] - 48;
            calcStack.push(num);
        }
        else            
        {
			double tempOne;
			double tempTwo;
            calcStack.pop(tempOne);

            calcStack.pop(tempTwo);

            if (expr[i] == '+')
            {
                result = tempOne + tempTwo;
                calcStack.push(result);
            }
            
            if (expr[i] == '-')
            {
                result = tempTwo - tempOne;
                calcStack.push(result);
            }
            
            if (expr[i] == '/')
            {
                result = tempTwo/tempOne;
                calcStack.push(result);
            }
            
            if (expr[i] == '*')
            {
                result = tempOne*tempTwo;
                calcStack.push(result);
            }
        }
	}
    return result;
}

bool isLowerPriority(char char1, char char2)
{
	int prec1, prec2;
	
	if (char1 == '+' || char1 == '-')
		prec1 = 1;
	if (char1 == '*' || char1 == '/')
		prec1 = 2;
	if (char1 == ')')
		prec1 = 3;
	if (char1 == '(')
		prec1 = 0;
	
	if (char2 == '+' || char2 == '-')
		prec2 = 1;
	if (char2 == '*' || char2 == '/')
		prec2 = 2;
	if (char2 == ')')
		prec2 = 3;
	if (char2 == '(')
		prec2 = 0;
	
	if (prec1 <= prec2)
		return true;
	if (prec1 > prec2)
		return false;
}

void removeSpaces(string &str)
{
	int count = 0;
	for (int i = 0; str[i]; i++)
	{
		if (str[i] != ' ')
			str[count++] = str[i];
	}
	str[count] = '\0';
}


void addSpacesBack(string &infix)
{
	cout << "Infix Expression: ";
	for (int i = 0; 2*infix[i]; i++)
	{
		cout << infix[i];
		cout << " ";
	}
}